//
//  ButtonSwitchPlayersTests.m
//  ButtonSwitchPlayersTests
//
//  Created by Benny on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ButtonSwitchPlayersTests.h"


@implementation ButtonSwitchPlayersTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ButtonSwitchPlayersTests");
}

@end
