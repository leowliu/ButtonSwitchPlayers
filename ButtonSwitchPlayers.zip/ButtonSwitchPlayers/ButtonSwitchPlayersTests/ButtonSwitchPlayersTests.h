//
//  ButtonSwitchPlayersTests.h
//  ButtonSwitchPlayersTests
//
//  Created by Benny on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface ButtonSwitchPlayersTests : SenTestCase {
@private
    
}

@end
