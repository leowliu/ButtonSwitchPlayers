//
//  SwitchView.h
//  ButtonSwitchPlayers
//
//  Created by Benny on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SwitchView : UIView {
    UIButton *audioButton;
    UIButton *videoButton;
    UISwitch *mySwitch;
}

@end
