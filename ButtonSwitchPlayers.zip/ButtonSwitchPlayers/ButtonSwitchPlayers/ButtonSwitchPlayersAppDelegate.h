//
//  ButtonSwitchPlayersAppDelegate.h
//  ButtonSwitchPlayers
//
//  Created by Benny on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVAudioPlayer.h>
#import <AudioToolbox/AudioToolbox.h>	//needed for SystemSoundID
@class SwitchView;

@interface ButtonSwitchPlayersAppDelegate : NSObject <UIApplicationDelegate, AVAudioPlayerDelegate> {

    MPMoviePlayerController *controller;
    SystemSoundID sid;
    AVAudioPlayer *player;
	SwitchView *switchView;
	UIWindow *_window;
}

- (void) valueChanged: (id) sender;

- (void) touchUpInside: (id) sender;

- (void) touchUpInside_1: (id) sender;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
